# Java Syntax Notes

Code লিখতে গিয়ে কোনো syntax ভুলে গেলে এখানে দেখার জন্য।
(AI এর সাহায্যে সাজানো personal reference notes)

---

## Files

| File | Topic |
|------|-------|
| [01-variables-and-datatypes.md](01-variables-and-datatypes.md) | Variable, Data Type |
| [02-operators.md](02-operators.md) | Arithmetic, Relational, Logical |
| [03-input-scanner.md](03-input-scanner.md) | Scanner দিয়ে Input নেওয়া |
| [04-type-casting.md](04-type-casting.md) | int ↔ double ↔ char ↔ String |
| [05-if-else-switch.md](05-if-else-switch.md) | If-Else, Ternary, Switch |
| [06-loops.md](06-loops.md) | For, While, Do-While, Nested |
| [07-arrays.md](07-arrays.md) | 1D, 2D Array |
| [08-strings.md](08-strings.md) | String Methods |
| [09-math-class.md](09-math-class.md) | Math.pow, sqrt, random... |
| [10-methods.md](10-methods.md) | Method, Overloading, Recursion |
| [11-oop-class-object.md](11-oop-class-object.md) | Class, Object, this, static |
| [12-constructor.md](12-constructor.md) | Constructor |
| [13-inheritance.md](13-inheritance.md) | extends, super |
| [14-encapsulation.md](14-encapsulation.md) | private, Getter/Setter |
| [15-polymorphism.md](15-polymorphism.md) | Overloading, Overriding |
| [16-abstract-interface.md](16-abstract-interface.md) | Abstract Class, Interface |
| [17-exception-handling.md](17-exception-handling.md) | try-catch, throw, Custom Exception |
| [18-arraylist.md](18-arraylist.md) | ArrayList, HashMap, HashSet |
| [19-file-readwrite.md](19-file-readwrite.md) | File Read/Write |
| [20-useful-patterns.md](20-useful-patterns.md) | Prime, Factorial, Fibonacci, Pattern, Sorting... |

---

## কোন Topic কোন File এ?

| খুঁজছি | কোথায় |
|--------|--------|
| Prime number | 20 (ছোট version: 10 এর `isPrime`) |
| Factorial | 20 (loop: 06, recursion: 10) |
| Fibonacci | 20 (recursion: 10) |
| Palindrome (number) | 20 |
| Palindrome (String) | 08 |
| Armstrong | 20 |
| Digit sum / reverse | 20 (digit বের করার নিয়ম: 06) |
| Star / number pattern | 20 (nested loop এর নিয়ম: 06) |
| Bubble sort, Linear / Binary search | 20 |
| Array max / min / sum | 07 |
| String compare (`equals`) | 08 |
| Input নেওয়া, `nextLine` সমস্যা | 03 |
| Input যতক্ষণ সঠিক না হয় (loop) | 06 (do-while) + 08 (equals) |
| Menu-driven program | 20 (switch এর নিয়ম: 05) |
| Random number | 09 |
| Constructor | 12 (`this` এর শুরু: 11) |
| `extends`, `super` | 13 |
| `private`, getter / setter | 14 |
| Overriding, Overloading | 15 (method overloading এর শুরু: 10) |
| `abstract`, `interface` | 16 |
| try-catch, `throw` | 17 |
| ArrayList, HashMap | 18 |
| File read / write, `input.txt` দিয়ে input | 19 |

---

## Run করার সময় মনে রাখো

- File এর নাম = `public class` এর নাম (`Test.java` → `public class Test`)
- Scanner এ input নিতে হলে terminal এ চালাও: `javac Test.java` তারপর `java Test`
- `println` এ বাংলা লিখলে Windows terminal এ `???` দেখাতে পারে — output এর text English এ রাখো, বাংলা শুধু comment এ

---

*Last updated: November 2026*
